#!/usr/bin/env python3
"""
This module is an emulator for Ben Eater's SAP-1 computer.

Usage:
    python3 main.py [--trace] sap-filename

The --trace flag causes trace output to be printed.

A program is loaded from a text file named on the command line.
Each line contains a hexadecimal or decimal memory address followed
by a space and then a value expressed in binary, hex, or decimal.
A comment starts with # and continues to the end of the line.
Note: Binary, hex, or decimal numbers follow Python syntax rules

Example input file contents:
# Add numbers
0x00 0b00011110 # LDA 14
0x01 0b00101111 # ADD 15
0x02 0b11100000 # OUT
0x03 0b11110000 # HLT
0x0E 0b00001110 # 14
0x0F 0b00011100 # 28
"""

import sys
import re
import argparse


class Halt(Exception):
    pass


class InvalidInstruction(Exception):
    pass


class SAP1:
    """
    An instance of a Simple-as-Possible-1 computer
    """

    OPCODES = {
        0b0000: 'NOP',
        0b0001: 'LDA',
        0b0010: 'ADD',
        0b0011: 'SUB',
        0b0100: 'STA',
        0b0101: 'LDIA',
        0b0110: 'JMP',
        # 0b0111: '???',
        0b1000: 'JC',
        # 0b1001: '???',
        # 0b1010: '???',
        # 0b1011: '???',
        # 0b1100: '???',
        # 0b1101: '???',
        0b1110: 'OUT',
        0b1111: 'HLT'
    }

    def __init__(self):
        """

        """
        # These represent the machine registers
        self.memory = [0] * 16
        self.A_register = 0
        self.B_register = 0
        self.PC_register = 0
        self.RAM = 0b0000
        self.MAR = 0b0000
        self.IR = 0
        self.Carry = 0

        # The tuple below can be indexed by an opcode to access a function that executes
        # that opcode
        self.decoder = (self.NOP, self.LDA, self.ADD, self.SUB, self.STA, self.LDIA, self.JMP, self.UND,
                        self.JC, self.UND, self.UND, self.UND, self.UND, self.UND, self.OUT, self.HLT)

    def NOP(self, other):
        """
        Execute a NOP instruction
        :param other: the low-order 4 bits of the instruction
        :return: None
        """
        # TODO
        pass

    def LDA(self, other):
        """
        Execute an LDA instruction
        :param other: the rightmost 4 bits of the instruction
        :return: None
        """
        # TODO
        pass

    def ADD(self, other):
        """
        Execute an ADD instruction
        :param other: the rightmost 4 bits of the instruction
        :return: None
        """
        # TODO
        pass

    def SUB(self, other):
        """
        Execute a SUB instruction
        :param other: the rightmost 4 bits of the instruction
        :return: None
        """
        # TODO
        pass

    def STA(self, other):
        """
        Execute an STA instruction
        :param other: the rightmost 4 bits of the instruction
        :return: None
        """
        # TODO
        pass

    def LDIA(self, other):
        """
        Execute an LDA instruction
        :param other: the rightmost 4 bits of the instruction
        :return: None
        """
        # TODO
        pass

    def JMP(self, other):
        """
        Execute a JMP instruction
        :param other: the rightmost 4 bits of the instruction
        :return: None
        """
        # TODO
        pass

    def LDI(self, other):
        """
        Execute an LDI instruction
        :param other: the rightmost 4 bits of the instruction
        :return: None
        """
        # TODO
        pass

    def JC(self, other):
        """
        Execute a JC instruction
        :param other: the rightmost 4 bits of the instruction
        :return: None
        """
        # TODO
        pass

    def OUT(self, other):
        """
        Execute an OUT instruction
        :param other: the rightmost 4 bits of the instruction
        :return: None
        """
        print('**** OUTPUT: {0:d}  0x{0:04X}  {0:04X}h  0b{0:08b}'.format(self.A_register))

    def HLT(self, other):
        """
        Execute a HLT instruction
        :param other: the rightmost 4 bits of the instruction
        :return: None
        :raise: Halt exception
        """
        raise Halt('HLT executed when PC is {}'.format(self.PC_register))

    def UND(self, other):
        """
        Execute an undefined instruction
        :param other: the rightmost 4 bits of the instruction
        :return: None
        :raise: InvalidInstruction exception
        """
        raise InvalidInstruction('Invalid opcode: 0x{0:02x}   0b{0:08b}'.format(self.IR))

    def fetch(self):
        """
        Set RAM to the contents of the memory location addressed by PC and then
        increment PC to the next address
        :return: None
        """
        # TODO
        pass

    def execute(self):
        """
        Execute the instruction by setting IR to the most significant nibble of IR
        and then calling the method associated with the opcode in IR, passing the
        least significant nibble as an argument
        :return: None
        """
        # Break the contents of IR into two nibbles
        # TODO
        self.IR = 0b1111 # STUB: HLT instruction

        # Call the method associated with the opcode in IR
        # TODO
        self.decoder[self.IR](0b0000)   # STUB

    def emulate(self, trace=False):
        """
        Run the program loaded in memory
        :param trace: True if machine state to be displayed after each instruction
        :return: None
        :raise: Halt when a HLT instruction is executed
        """

        try:
            # Fetch-execute cycle
            while True:
                if trace:
                    print(f'Fetch instruction at address {self.PC_register}')
                self.fetch()
                if trace:
                    print(f'Execute instruction {self.IR:02X}', end='')
                    print('    {:<4s}\t{:02X}'.format(self.OPCODES.get(self.RAM // 16, '???'), self.RAM % 16))

                self.execute()
                if trace:
                    print()
                    print("After execution:")
                    print(self)
        except Halt as e:
            if trace:
                print('HLT encountered')
                print(self)
            print(e)
        except InvalidInstruction as e:
            print(e)

    def load(self, filename):
        """
        Load the program from a file
        :param filename:
        :return: None
        :raise: ValueError if file contains a formatting error
        """
        with open(filename) as program_file:
            for line in program_file:
                # Remove any comment part and leading or trailing spaces
                line = re.sub(r'#.*$', '', line).strip()
                if line:
                    addr, value = line.split()
                    # See: https://stackoverflow.com/questions/604240/how-to-parse-hex-or-decimal-int-in-python
                    # See also: https://docs.python.org/3/library/functions.html#int
                    self.memory[int(addr, 0)] = int(value, 0)

    def __str__(self):
        """
        Return a string showing the current machine state
        :return: a str
        """
        # Print the machine state
        # self.memory = [0] * 16
        # self.A_register = 0
        # self.B_register = 0
        # self.PC_register = 0
        # self.RAM = '0000'
        # self.MAR = '0000'
        # self.IR = 0
        # self.Carry = 0

        # Build a list containing each component of the state
        lines = ["STATE:",
                 "   PC:  {0:04b}  0x{0:04X}".format(self.PC_register),
                 "   IR:  {0:04b}  0x{0:04X}".format(self.IR),
                 "    A:  {0:04b}  0x{0:04X}".format(self.A_register),
                 "    B:  {0:04b}  0x{0:04X}".format(self.B_register),
                 "  MAR:  {0:04b}  0x{0:04X}".format(int(self.MAR)),
                 "  RAM:  {0:04b}  0x{0:04X}".format(int(self.RAM)),
                 "Carry:  {0:04b}  0x{0:04X}".format(self.Carry),
                 "Memory:"]
        lines .extend(['    {0:04b}: {1:08b}  {1:3d}  0x{1:04X}'.format(addr, value) for addr, value in enumerate(self.memory)])

        return '\n    '.join(lines)


def main():
    """
    Load the program in a file named as a command line argument
    :return: None
    """

    ap = argparse.ArgumentParser(prog='sap', description='Simulate execution of a SAP1 program')
    ap.add_argument('filename',
                    metavar='filename',
                    type=str,
                    help='the name of the file containing binary')
    ap.add_argument('-t',
                    '--trace',
                    action='store_true',
                    help='display state after each instruction')

    args = ap.parse_args()
    filename = args.filename
    trace = args.trace

    computer = SAP1()

    print ("START")
    # print(computer)

    try:
        computer.load(args.filename)
        if trace:
            print(f'Load of {filename} complete.')
            print(computer)
            print()

        computer.emulate(trace=trace)

    except FileNotFoundError:
        print("Could not open file {}.".format(filename), file=sys.stderr)

    except ValueError:
        print("Error reading file {}.".format(filename), file=sys.stderr)


if __name__ == '__main__':
    main()
